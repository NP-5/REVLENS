import json
import os

from flask import Flask, render_template, request, jsonify, send_from_directory, abort

from revlens_core import db, ingest, routing, export as export_mod, brief as brief_mod

app = Flask(__name__)
DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")


def ensure_db():
    if not os.path.exists(db.DB_PATH):
        db.init_db()
    else:
        db.init_db()  # idempotent CREATE IF NOT EXISTS, safe on every boot


ensure_db()


# ---------------------------------------------------------------------------
# Pages
# ---------------------------------------------------------------------------

@app.route("/")
def landing():
    return render_template("landing.html")


@app.route("/app")
def dashboard():
    return render_template("dashboard.html")


@app.route("/app/conversation/<source_type>/<source_id>")
def conversation_detail(source_type, source_id):
    return render_template("conversation.html", source_type=source_type, source_id=source_id)


@app.route("/app/brief")
def brief_page():
    return render_template("brief.html")


@app.route("/app/exports")
def exports_page():
    return render_template("exports.html")


@app.route("/exports/<path:filename>")
def serve_export_file(filename):
    return send_from_directory(export_mod.EXPORTS_ROOT, filename)


# ---------------------------------------------------------------------------
# API: state / import
# ---------------------------------------------------------------------------

@app.route("/api/state")
def api_state():
    conn = db.get_conn()
    total = conn.execute("SELECT COUNT(*) c FROM conversations").fetchone()["c"]
    usable = conn.execute("SELECT COUNT(*) c FROM conversations WHERE has_usable_text=1").fetchone()["c"]
    calls = conn.execute("SELECT COUNT(*) c FROM conversations WHERE source_type='call'").fetchone()["c"]
    meetings = conn.execute("SELECT COUNT(*) c FROM conversations WHERE source_type='meeting'").fetchone()["c"]
    history = [dict(r) for r in conn.execute("SELECT * FROM import_history ORDER BY id").fetchall()]
    conn.close()
    return jsonify({
        "total_records": total, "usable_text": usable, "calls": calls, "meetings": meetings,
        "import_history": history,
    })


@app.route("/api/import/sample/<which>", methods=["POST"])
def api_import_sample(which):
    """which = 'initial' or 'update' — imports the assignment's supplied files by path,
    so the replay steps in the brief can be reproduced from the UI with one click."""
    fname = {"initial": "01_initial.json", "update": "02_update.json"}.get(which)
    if not fname:
        return jsonify({"error": "unknown sample, use 'initial' or 'update'"}), 400
    path = os.path.join(DATA_DIR, fname)
    with open(path, "rb") as f:
        raw = f.read()
    result = ingest.apply_batch(raw, filename=fname)
    return jsonify(result)


@app.route("/api/import/upload", methods=["POST"])
def api_import_upload():
    if "file" not in request.files:
        return jsonify({"error": "no file supplied"}), 400
    f = request.files["file"]
    raw = f.read()
    result = ingest.apply_batch(raw, filename=f.filename)
    return jsonify(result)


@app.route("/api/reset", methods=["POST"])
def api_reset():
    db.reset_db()
    return jsonify({"ok": True})


# ---------------------------------------------------------------------------
# API: conversations / dashboard
# ---------------------------------------------------------------------------

def _conv_with_routes(conn, row):
    c = dict(row)
    routes = routing.active_routes_for(conn, c["source_type"], c["source_id"])
    c["routes"] = routes
    c["analysis"] = json.loads(c["analysis_json"]) if c["analysis_json"] else None
    return c


@app.route("/api/conversations")
def api_conversations():
    person = request.args.get("person")
    source_type = request.args.get("source_type")
    route = request.args.get("route")
    review_only = request.args.get("review_only")

    conn = db.get_conn()
    rows = conn.execute("SELECT * FROM conversations ORDER BY occurred_at_utc").fetchall()
    results = []
    for row in rows:
        c = _conv_with_routes(conn, row)
        person_key = c["person_email"] or c["person_label"]
        if person and person_key != person:
            continue
        if source_type and c["source_type"] != source_type:
            continue
        if route and route not in [r["route"] for r in c["routes"]]:
            continue
        if review_only == "1" and c["has_usable_text"]:
            continue
        results.append(c)
    conn.close()
    return jsonify(results)


@app.route("/api/conversation/<source_type>/<source_id>")
def api_conversation_detail(source_type, source_id):
    conn = db.get_conn()
    row = conn.execute(
        "SELECT * FROM conversations WHERE source_type=? AND source_id=?", (source_type, source_id)
    ).fetchone()
    if not row:
        conn.close()
        abort(404)
    c = _conv_with_routes(conn, row)
    src = conn.execute(
        "SELECT * FROM source_records WHERE source_type=? AND source_id=?", (source_type, source_id)
    ).fetchone()
    c["payload"] = json.loads(src["payload_json"])
    c["transcript_payload"] = json.loads(src["transcript_payload_json"]) if src["transcript_payload_json"] else None
    conn.close()
    return jsonify(c)


@app.route("/api/route/<source_type>/<source_id>", methods=["POST"])
def api_set_route(source_type, source_id):
    body = request.get_json(force=True)
    new_route = body.get("route")
    reason = body.get("reason")
    if new_route not in routing.ROUTE_LABELS:
        return jsonify({"error": "unknown route"}), 400
    conn = db.get_conn()
    row = conn.execute(
        "SELECT * FROM conversations WHERE source_type=? AND source_id=?", (source_type, source_id)
    ).fetchone()
    if not row:
        conn.close()
        abort(404)
    routing.set_manual_route(conn, source_type, source_id, new_route, reason, row["revision"])
    conn.commit()
    c = _conv_with_routes(conn, conn.execute(
        "SELECT * FROM conversations WHERE source_type=? AND source_id=?", (source_type, source_id)
    ).fetchone())
    conn.close()
    return jsonify(c)


@app.route("/api/route/<source_type>/<source_id>/reset", methods=["POST"])
def api_reset_route(source_type, source_id):
    conn = db.get_conn()
    row = conn.execute(
        "SELECT * FROM source_records WHERE source_type=? AND source_id=?", (source_type, source_id)
    ).fetchone()
    if not row:
        conn.close()
        abort(404)
    payload = json.loads(row["payload_json"])
    tpayload = json.loads(row["transcript_payload_json"]) if row["transcript_payload_json"] else None
    routing.reset_to_auto(conn, source_type, source_id, row["revision"], payload, tpayload)
    conn.commit()
    c = _conv_with_routes(conn, conn.execute(
        "SELECT * FROM conversations WHERE source_type=? AND source_id=?", (source_type, source_id)
    ).fetchone())
    conn.close()
    return jsonify(c)


@app.route("/api/metrics")
def api_metrics():
    """Dashboard headline metrics, each with an explicit denominator so a reviewer
    can see exactly what was counted."""
    conn = db.get_conn()
    total = conn.execute("SELECT COUNT(*) c FROM conversations").fetchone()["c"]
    usable = conn.execute("SELECT COUNT(*) c FROM conversations WHERE has_usable_text=1").fetchone()["c"]

    conn_known = conn.execute(
        "SELECT COUNT(*) c FROM conversations WHERE source_type='call' AND connected_status IN ('connected','not_connected')"
    ).fetchone()["c"]
    conn_true = conn.execute(
        "SELECT COUNT(*) c FROM conversations WHERE source_type='call' AND connected_status='connected'"
    ).fetchone()["c"]
    conn_unknown = conn.execute(
        "SELECT COUNT(*) c FROM conversations WHERE source_type='call' AND connected_status='unknown'"
    ).fetchone()["c"]

    by_person_rows = conn.execute(
        "SELECT COALESCE(person_email, person_label) AS grp, person_label, source_type, COUNT(*) c, SUM(has_usable_text) usable FROM conversations GROUP BY grp, source_type"
    ).fetchall()
    by_person = {}
    display_label = {}
    for r in by_person_rows:
        key = r["grp"] or "Unknown"
        by_person.setdefault(key, {"calls": 0, "meetings": 0, "usable_text": 0, "total": 0})
        by_person[key]["total"] += r["c"]
        by_person[key]["usable_text"] += r["usable"] or 0
        if r["person_label"]:
            current = display_label.get(key)
            if current is None or ("@" in current and "@" not in r["person_label"]):
                display_label[key] = r["person_label"]
        if r["source_type"] == "call":
            by_person[key]["calls"] += r["c"]
        else:
            by_person[key]["meetings"] += r["c"]

    for key, v in by_person.items():
        v["display_label"] = display_label.get(key, key)

    route_rows = conn.execute(
        "SELECT route, COUNT(*) c, SUM(is_manual) manual FROM routes WHERE is_active=1 GROUP BY route"
    ).fetchall()
    routes_summary = {r["route"]: {"count": r["c"], "manual": r["manual"] or 0} for r in route_rows}
    labelled_route_assignments = sum(v["count"] for v in routes_summary.values())

    conn.close()
    return jsonify({
        "selected_records_total": total,
        "usable_supplied_text": usable,
        "coverage_pct": round(usable / total * 100, 1) if total else 0.0,
        "coverage_definition": "usable supplied texts ÷ selected source records currently in view",
        "connection_rate": {
            "connected": conn_true,
            "known_denominator": conn_known,
            "unknown_excluded": conn_unknown,
            "pct": round(conn_true / conn_known * 100, 1) if conn_known else None,
            "definition": "calls with is_connected=true ÷ calls with non-null is_connected (source-reported; excludes unknown)",
        },
        "by_person": by_person,
        "routes_summary": routes_summary,
        "labelled_route_assignments": labelled_route_assignments,
        "unique_records": total,
        "route_vs_record_note": "labelled_route_assignments can exceed unique_records because one conversation may need more than one route.",
    })


@app.route("/api/brief")
def api_brief():
    return jsonify(brief_mod.generate_brief())


# ---------------------------------------------------------------------------
# API: export
# ---------------------------------------------------------------------------

@app.route("/api/export", methods=["POST"])
def api_export():
    result = export_mod.run_export()
    return jsonify({
        "run_id": result["run_id"],
        "file_count": result["file_count"],
        "records": result["records"],
        "manifest_url": f"/exports/{result['run_id']}/manifest.json",
        "manifest_csv_url": f"/exports/{result['run_id']}/manifest.csv",
    })


@app.route("/api/exports")
def api_exports_list():
    return jsonify(export_mod.list_export_runs())


if __name__ == "__main__":
    app.run(debug=True, port=5050)
