# RevLens — Revenue Intelligence Inbox

A workspace that turns scattered calls, meeting recordings and automated notes into
something a sales manager can act on: what happened, what needs attention, and what
to do next — with every conclusion traceable back to the source text.

Built for the SpendNest revenue-intelligence take-home exercise, against the supplied
`data/01_initial.json` and `data/02_update.json`.

---

## Setup (VS Code / local)

Requires Python 3.10+.

```bash
cd revlens
python3 -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python3 app.py
```

Open **http://127.0.0.1:5050** — that's the landing page. Click **"Open workspace"**
to get to the dashboard at `/app`.

The database is a single SQLite file at `instance/revlens.db`, created automatically
on first run. Exports are written under `exports/<timestamp>/`.

### Demo-load / reset

- **Clean start**: click **Reset** in the dashboard toolbar, or `POST /api/reset`,
  or just delete `instance/revlens.db` and restart the app.
- **Load both batches** (post-update state): click **"Import initial batch"** then
  **"Import update batch"** in the dashboard toolbar, or:
  ```bash
  curl -X POST http://127.0.0.1:5050/api/import/sample/initial
  curl -X POST http://127.0.0.1:5050/api/import/sample/update
  ```
  The app does **not** auto-load data on boot — this one documented action is the
  demo-load step referenced in the assignment.

---

## Reproducing the replay checks

The dashboard's **Import initial batch** / **Import update batch** buttons call the
same pipeline as this scripted sequence:

```bash
BASE=http://127.0.0.1:5050

curl -X POST $BASE/api/reset                              # clean start
curl -X POST $BASE/api/import/sample/initial               # 44 new, 17 usable texts
curl -X POST $BASE/api/import/sample/initial               # repeat: 0 new, 44 ignored (stale revision)

# find M07's source_id (meeting) from data/02_update.json, then correct its route:
curl -X POST $BASE/api/route/meeting/<M07_source_id> \
     -H "Content-Type: application/json" \
     -d '{"route":"deal_next_steps","reason":"manual test correction"}'

curl -X POST $BASE/api/import/sample/update                 # total stays 44, usable text 17 -> 18
curl -X POST $BASE/api/import/sample/initial                 # older revision again: ignored

# restart the app (Ctrl+C, `python3 app.py` again), or refresh the dashboard —
curl http://127.0.0.1:5050/api/conversation/meeting/<M07_source_id>
# -> M07's newer transcript is visible, its manual route ("deal_next_steps") is
#    still active, and every other record is unchanged.
```

I ran this exact sequence during development; see the "known limitations" section
below for the one edge case it surfaces.

---

## Where outputs are written

`POST /api/export` (or the **Run export** button on `/app/exports`) writes a fresh
timestamped folder under `exports/`:

```
exports/<run_id>/
  manifest.json          # one row per (record, route) — see fields below
  manifest.csv            # same data, flat
  by_route/<route>/<ref>.md     # one file per conversation per active route
  by_person/<person>/<ref>.md   # convenience copy, findability only — not a second identity
```

A repeat export writes a new timestamped run rather than overwriting the previous
one in place, so nothing is silently lost; the dashboard's Exports page lists every
run and links straight to its manifest.

**Manifest fields**: `source_type`, `source_id`, `record_ref`, `applied_source_revision`,
`analysis_reflects_revision`, `analysis_current` (bool — does the analysis reflect the
latest imported revision), `route`, `route_label`, `manual_override` (bool),
`stale_flag`, `processing_state`, `output_path` (relative to the run folder), `active`.

---

## Metric definitions (also shown inline in the dashboard, under each number)

- **Selected source records**: distinct `(source_type, source_id)` pairs currently
  stored, after revisions are applied. Always ≤ 44 for this package; never inflated
  by a repeat import.
- **Usable-text coverage**: usable supplied texts ÷ selected source records in the
  same filter. "Usable" = a nonblank call `transcript`, or at least one meeting turn
  with nonblank `text`.
- **Source-reported connection rate**: calls with `is_connected=true` ÷ calls with
  non-null `is_connected`. Calls with `is_connected=null` are shown separately as
  "unknown" and excluded from the denominator — this is explicitly the *stored*
  classification, not a transcript-verified measure.
- **Labelled route assignments**: total active route rows across all conversations.
  This can exceed the record count, because one conversation can need more than one
  route (e.g. both coaching *and* deal next steps) — the dashboard shows both numbers
  side by side rather than picking one.

All dates use Asia/Kolkata. Every headline number's definition is visible in the
dashboard itself, not just here.

---

## Routing categories

Deterministic, rule-based (keyword + structure matching over the transcript text),
**no paid AI call is used or required**:

| Route | Roughly means |
|---|---|
| `sales_coaching` | An objection, budget concern or competitive mention appears — useful for coaching how it was handled. |
| `deal_next_steps` | An identifiable buying-process next step is present. |
| `customer_follow_up` | An operational issue, delay or dissatisfaction that likely needs an owner. |
| `internal_vendor_note` | The other party reads as a partner/vendor/referral, not a prospect or customer. |
| `needs_review` | No usable text at all, or usable text with no rule match — a human should read it and decide. Nothing substantive is invented here. |

A conversation can receive more than one route. Every route carries a `reason` and an
`evidence_ref` (a turn number for meetings, a short exact quote for calls) so a
manager can check the suggestion against the source text before trusting it, and can
correct it from the conversation detail page — that correction is stored separately
from the automated suggestion and survives future imports (see `revlens_core/routing.py`
and `import rules #4` in the original `DATA_CONTRACT.md`).

## Is analysis pre-generated or generated at runtime?

**Generated at runtime**, by deterministic rules in `revlens_core/routing.py`
(`analyze_conversation`) — no external/paid AI call. This was a deliberate choice: the
routing logic needed to be inspectable, re-run automatically the instant new source
text lands (the M07 late-transcript case), and fully reproducible without an API key
in the submission. The **manager brief** (`revlens_core/brief.py`) is also computed at
runtime from whatever is currently in the database, filtered to 21 Aug 2026 IST, but
is intentionally *not* reactive to the dashboard's person/route filters (per the
assignment).

---

## Architecture

```
revlens/
  app.py                    Flask app: pages + JSON API
  revlens_core/
    db.py                   SQLite schema (source_records, conversations, signals, routes, import_history, exports)
    ingest.py                Stages 1-4: format detection, normalize, validate, dedupe/upsert-by-revision
    routing.py                Stage: rule-based routing + evidence extraction, manual-override handling
    export.py                 Stage: folder + manifest generation
    brief.py                   Manager brief for 21 Aug 2026 IST
  templates/, static/          Landing page + dashboard UI (server-rendered shell, vanilla JS for data)
  data/                         The two supplied delivery files
```

Identity is always `(source_type, source_id)` — never name, `record_ref`, or array
position, per the data contract. A newer revision replaces the entire source payload
(including nulls); a same-or-older revision is ignored. Manual route corrections are
stored in a separate `routes` row (`is_manual=1`) and are never touched by an
automatic re-route; only an explicit "Reset to auto" clears one.

---

## Key findings from this data package

Computed by running the actual pipeline against `data/01_initial.json` +
`data/02_update.json` (44 records, 18 with usable text after both batches).

1. **The transcript gap is a call-connection problem, not a missing-data problem.**
   Of the 30 calls, 19 never connected (`connected_status: not_connected`), and the
   `needs_review` reasons break down as 15 voicemails + 3 unresponsive — accounting
   for 18 of the 20 "no transcript" calls. Only **B11** and **B14** were actually
   marked `connected` yet still arrived with no transcript ("Call has no usable
   transcript supplied in this package") — that pair is the real data gap worth
   chasing with the source system, distinct from the voicemail noise.

2. **`customer_follow_up` is the single largest active route** — 11 of 57 total
   active route assignments across the 18 usable-text conversations, ahead of
   `sales_coaching` (7), `deal_next_steps` (6) and `internal_vendor_note` (5). Most
   conversations that *do* carry usable text surface an open operational thread
   (e.g. **M02**'s ask about "compliant invoicing coverage across our operating
   markets") rather than a clean, closed interaction.

3. **Over half of usable conversations need more than one route.** 10 of the 18
   usable-text conversations triggered 2–3 routes simultaneously — **M01**, **M04**
   and **M06** each hit all three of `internal_vendor_note`/`deal_next_steps`,
   `sales_coaching`, and `customer_follow_up` in the same meeting. This is why
   routing is modelled as a list per conversation rather than a single label: a
   single-label design would have silently dropped roughly a third of the labelled
   work items.

---

## A decision I deliberately rejected

**Rejected**: routing/classification via an LLM call (e.g. sending each transcript
to Claude or GPT with a classification prompt) instead of the deterministic
keyword-rule engine actually shipped.

**Reason for rejecting it**: an LLM classifier would likely catch paraphrased or
unusually-phrased signals that the keyword rules miss, but it would make every
routing decision a black box — a manager couldn't see *why* a conversation landed
in `sales_coaching` without re-reading the whole transcript, it would need an API
key to reproduce in the submission, and it couldn't be guaranteed to re-run
identically when the M07 late-transcript case needed instant, deterministic
re-analysis on import.

**Trade-off accepted**: the shipped rule engine is fully inspectable (every route
carries its exact `reason` and evidence quote), free to re-run, and reproducible
with no external dependency — at the cost of missing signals phrased outside the
matched keywords, and occasionally matching a keyword out of context (see
"Known limitations" below). I judged transparency and reproducibility to matter
more than incremental recall for this exercise.

---

## Known limitations / what I'd improve next

- **Routing is keyword-based**, not a language model. It's inspectable and free to
  re-run, but it will miss signals phrased unusually and can occasionally match a
  keyword out of context (e.g. "trial" appearing in a sentence that isn't actually
  proposing a trial). Every route shows its evidence specifically so this is checkable,
  not hidden.
- **Identity across records is limited to what the source data supports.** Calls
  report a `rep_email`/`rep_name`; meetings only report `organizer_email` (not
  necessarily the seller, per the data dictionary). The dashboard groups by e-mail
  where available and falls back to the display name otherwise, but there's no
  verified cross-record person directory, and I don't invent one. Every person label
  in the UI — the dashboard table and the conversation detail header — carries a
  small `rep`/`organiser` tag; hovering the `organiser` tag (or opening a meeting's
  detail page, where the caveat is spelled out beneath the header) surfaces the
  dictionary's own wording that an organiser is not proof of attendance or a
  confirmed selling role.
- **Stale-analysis flagging is visual only, not a blocking workflow.** When a manual
  route is set and a later update changes the source text, the route stays active but
  is flagged `stale`/"review" in the UI — nothing forces a manager to actually look at
  it. This is a maintainable v1 boundary, but a "review updated records" queue would
  be a nice addition — right now you have to open each updated conversation to see the
  freshness note.
- **CSV/plain-transcript ingest paths are implemented but lightly tested** — the
  assignment's real fixtures are the JSON envelope, so that path has the most
  scrutiny. The CSV/txt paths exist so the ingest stage isn't hard-wired to one
  format (see the landing page's "01 Ingest" step), but a production version would
  need a stricter CSV field-mapping UI rather than assuming fixed column names.
- **No account/company matching** and no pipeline-value totals are shown, by design —
  the data dictionary is explicit that no verified company-ID join or CRM opportunity
  table is supplied, and I didn't want to fabricate either.

---

## Time spent

Approximately 7 hours: reading the brief/contract/dictionary and inspecting the data
(~1h), pipeline + storage + routing engine (~2.5h), dashboard/landing/detail UI
(~2h), export + manager brief (~1h), replay testing and this README (~0.5h).

## AI usage disclosure

Built with AI coding assistance (Claude) end-to-end, per the assignment's explicit
allowance for AI tools. I supplied the requirements review, the routing-category
design, the schema/identity decisions, and did the replay verification described
above; the assistant generated the implementation from those decisions.
