"""
Stage 2 of the product (not the ingest pipeline): ROUTING.

Deterministic, keyword/rule-based classification of each conversation's usable
text into one or more destinations. No paid AI call is used or required, per
the assignment ("Updated content does not have to trigger a paid AI service").

Every assigned route carries:
  - a short human-readable reason
  - an evidence reference (turn number for meetings, a short exact quote for calls)
so a manager can verify the suggestion against the source text before trusting it.

Routes
------
needs_review        - no usable text at all; nothing substantive can be concluded.
sales_coaching       - rep-side behaviour worth coaching (objection handling, silence,
                       mis-set expectations, voicemail-only outreach).
deal_next_steps      - active buyer-side evaluation with an identifiable next step.
customer_follow_up   - existing customer raising an issue, risk or open request.
internal_vendor_note - the other party is a vendor/partner/referral, not a prospect
                       or existing customer; conversation is administrative/internal.

A conversation may receive more than one route. Rules are intentionally
conservative: text with no matching signal is routed only to `needs_review`
with a reason that says a human should read it and decide, rather than being
forced into a category the evidence does not support.
"""

import json
import re
from datetime import datetime, timezone

from . import db

ROUTE_LABELS = {
    "sales_coaching": "Sales coaching",
    "deal_next_steps": "Deal next steps",
    "customer_follow_up": "Customer follow-up",
    "internal_vendor_note": "Internal / vendor note",
    "needs_review": "Needs review",
}

# --- keyword sets (lowercase match) -----------------------------------------

BUYER_NEXT_STEP = [
    "send over a contract", "send the contract", "send a proposal", "next step",
    "send pricing", "trial", "follow up next week", "loop in", "get back to you",
    "set up a follow", "schedule a", "send you the", "i can send", "what's the pricing",
    "what is the pricing", "when can we start", "sign up", "onboarding",
]
COMPETITOR_OR_OBJECTION = [
    "already using", "we currently use", "competitor", "too expensive", "not sure this is",
    "budget", "not convinced", "hesitant", "concerned about", "not interested",
    "already have a provider", "recommending other", "other providers",
]
CUSTOMER_ISSUE = [
    "isn't working", "is not working", "not working", "issue with", "problem with",
    "invoice", "reconciliation", "reconcile", "didn't sync", "did not sync", "sync issue",
    "declined", "charged twice", "double charge", "wrong amount", "refund", "delay in",
    "still waiting", "escalate", "frustrated", "unhappy",
]
VENDOR_OR_PARTNER = [
    "advisory", "partner", "referral", "our clients", "recommend", "on behalf of",
    "reseller", "consultancy", "consulting", "white-label", "white label",
]
COMMITMENT_LANGUAGE = [
    "i will", "i'll send", "we will", "we'll", "by friday", "by monday", "next week i",
]

VOICEMAIL_OUTCOMES = {"voicemail", "no_answer", "no-answer"}


def _find_quote(text, keyword, context_chars=90):
    idx = text.lower().find(keyword)
    if idx == -1:
        return None
    start = max(0, idx - context_chars // 2)
    end = min(len(text), idx + len(keyword) + context_chars // 2)
    snippet = text[start:end].strip()
    snippet = re.sub(r"\s+", " ", snippet)
    if start > 0:
        snippet = "…" + snippet
    if end < len(text):
        snippet = snippet + "…"
    return snippet


def _scan_call_text(text):
    """Returns list of (keyword_set_name, matched_keyword, quote) for a flat call transcript."""
    hits = []
    for name, kwlist in (
        ("buyer_next_step", BUYER_NEXT_STEP),
        ("competitor_or_objection", COMPETITOR_OR_OBJECTION),
        ("customer_issue", CUSTOMER_ISSUE),
        ("vendor_or_partner", VENDOR_OR_PARTNER),
        ("commitment", COMMITMENT_LANGUAGE),
    ):
        for kw in kwlist:
            if kw in text.lower():
                hits.append((name, kw, _find_quote(text, kw)))
                break  # one representative hit per category keeps evidence readable
    return hits


def _scan_turns(turns):
    """Returns list of (keyword_set_name, matched_keyword, turn_number, quote) for meeting turns."""
    hits = []
    for name, kwlist in (
        ("buyer_next_step", BUYER_NEXT_STEP),
        ("competitor_or_objection", COMPETITOR_OR_OBJECTION),
        ("customer_issue", CUSTOMER_ISSUE),
        ("vendor_or_partner", VENDOR_OR_PARTNER),
        ("commitment", COMMITMENT_LANGUAGE),
    ):
        found = False
        for i, turn in enumerate(turns, start=1):
            text = (turn.get("text") or "")
            for kw in kwlist:
                if kw in text.lower():
                    hits.append((name, kw, i, text.strip()))
                    found = True
                    break
            if found:
                break
    return hits


def analyze_conversation(source_type, payload, transcript_payload):
    """
    Pure function: given a conversation's payload/transcript, returns
    (routes: list[{route, reason, evidence_ref, evidence_quote, rule_name}],
     findings: dict with a short narrative)
    with no side effects. Called both for fresh routing and for re-analysis
    after an update.
    """
    if source_type == "call":
        text = (payload.get("transcript") or "").strip()
        outcome = (payload.get("observed_outcome") or "").lower()
        if not text:
            if outcome in VOICEMAIL_OUTCOMES or (payload.get("is_connected") is False):
                reason = "Call has no usable transcript and was not connected (source-reported outcome: %s)." % (payload.get("observed_outcome") or "unknown")
            else:
                reason = "Call has no usable transcript supplied in this package."
            return [{"route": "needs_review", "reason": reason, "evidence_ref": None, "evidence_quote": None, "rule_name": "no_text"}], {
                "headline": "No usable text — awaiting a transcript or manual review.",
                "what_happened": reason,
                "not_established": "Nothing about call content can be concluded from metadata alone.",
                "next_step": "A human should confirm whether this call needs a callback or can be closed out.",
            }
        hits = _scan_call_text(text)
        return _routes_from_hits(hits, is_call=True), _findings_from_hits(hits, text[:280], is_call=True)

    # meeting
    turns = (transcript_payload or {}).get("turns") or []
    usable = [t for t in turns if (t.get("text") or "").strip()]
    if not usable:
        unavailable = (transcript_payload or {}).get("unavailable_reason") if transcript_payload else None
        reason = unavailable or "Meeting has has_transcript=%s but no usable turns were supplied." % payload.get("has_transcript")
        return [{"route": "needs_review", "reason": reason, "evidence_ref": None, "evidence_quote": None, "rule_name": "no_text"}], {
            "headline": "No usable text — awaiting a transcript or manual review.",
            "what_happened": reason,
            "not_established": "A missing transcript does not establish the meeting never happened.",
            "next_step": "A human should confirm attendance/outcome from another source if this matters.",
        }
    hits = _scan_turns(usable)
    return _routes_from_hits(hits, is_call=False), _findings_from_hits(hits, usable[0]["text"][:280], is_call=False)


def _routes_from_hits(hits, is_call):
    routes = []
    kinds_present = {h[0] for h in hits}

    def add(route, reason, hit):
        if is_call:
            _, kw, quote = hit
            evidence_ref = f"exact quote: “{quote}”" if quote else None
        else:
            _, kw, turn_no, quote = hit
            evidence_ref = f"turn {turn_no}"
            quote = (quote[:220] + "…") if quote and len(quote) > 220 else quote
        routes.append({"route": route, "reason": reason, "evidence_ref": evidence_ref, "evidence_quote": quote, "rule_name": hit[0]})

    hit_by_kind = {h[0]: h for h in hits}

    if "vendor_or_partner" in kinds_present:
        add("internal_vendor_note",
            "Language suggests the other party is a partner/vendor/referral source rather than a direct prospect or existing customer.",
            hit_by_kind["vendor_or_partner"])

    if "buyer_next_step" in kinds_present:
        add("deal_next_steps",
            "An identifiable next step or buying-process language was found in the conversation.",
            hit_by_kind["buyer_next_step"])

    if "customer_issue" in kinds_present:
        add("customer_follow_up",
            "The conversation raises an operational issue, delay or dissatisfaction that likely needs a follow-up owner.",
            hit_by_kind["customer_issue"])

    if "competitor_or_objection" in kinds_present:
        add("sales_coaching",
            "An objection, budget concern or competitive mention appears; useful for coaching how it was (or wasn't) handled.",
            hit_by_kind["competitor_or_objection"])

    if not routes:
        # Usable text exists but no rule matched — do not force a category.
        routes.append({
            "route": "needs_review",
            "reason": "Usable text is present but no routing rule matched with confidence; a human should read it and decide.",
            "evidence_ref": None, "evidence_quote": None, "rule_name": "no_rule_match",
        })
    return routes


def _findings_from_hits(hits, opening_text, is_call):
    if not hits:
        return {
            "headline": "Text is available but no strong signal was auto-detected.",
            "what_happened": (opening_text + "…") if opening_text else "No summary available.",
            "not_established": "No buying, issue, or coaching signal matched the routing rules; this does not mean nothing important happened.",
            "next_step": "A human reviewer should read the transcript directly.",
        }
    kinds = [h[0] for h in hits]
    headline_parts = []
    if "buyer_next_step" in kinds:
        headline_parts.append("a buying next step")
    if "customer_issue" in kinds:
        headline_parts.append("an operational issue")
    if "competitor_or_objection" in kinds:
        headline_parts.append("an objection or competitive mention")
    if "vendor_or_partner" in kinds:
        headline_parts.append("partner/vendor context")
    headline = "Conversation surfaces " + ", ".join(headline_parts) + "."
    return {
        "headline": headline,
        "what_happened": (opening_text + "…") if opening_text else "",
        "not_established": "Routing is keyword-based evidence, not a verified deal outcome, account match or confirmed ownership.",
        "next_step": "See the route reasons below and the linked evidence for what to do next.",
    }


# --- persistence --------------------------------------------------------

def route_and_store(conn, source_type, source_id, revision, payload, transcript_payload):
    """Deactivates prior AUTO routes for this record and stores fresh auto routes.
    Never touches manual routes (contract rule #4)."""
    conn.execute(
        "UPDATE routes SET is_active=0 WHERE source_type=? AND source_id=? AND is_manual=0",
        (source_type, source_id),
    )
    routes, findings = analyze_conversation(source_type, payload, transcript_payload)
    now = datetime.now(timezone.utc).isoformat()
    for r in routes:
        conn.execute(
            """INSERT INTO routes (source_type, source_id, route, reason, is_manual, is_active, source_revision, stale, created_at)
               VALUES (?,?,?,?,0,1,?,0,?)""",
            (source_type, source_id, r["route"], r["reason"], revision, now),
        )
    conn.execute(
        "UPDATE conversations SET analysis_json=?, analysis_revision=? WHERE source_type=? AND source_id=?",
        (json.dumps(findings), revision, source_type, source_id),
    )
    return routes, findings


def set_manual_route(conn, source_type, source_id, route, reason, revision):
    """Records a manual override. Deactivates other manual routes for this record
    (a manager can hold multiple manual routes if desired — here we treat the
    correction UI as "set the route to X", so we deactivate prior manual routes
    but always leave the underlying auto routes' history intact for audit)."""
    conn.execute(
        "UPDATE routes SET is_active=0 WHERE source_type=? AND source_id=? AND is_manual=1",
        (source_type, source_id),
    )
    now = datetime.now(timezone.utc).isoformat()
    conn.execute(
        """INSERT INTO routes (source_type, source_id, route, reason, is_manual, is_active, source_revision, stale, created_at)
           VALUES (?,?,?,?,1,1,?,0,?)""",
        (source_type, source_id, route, reason or "Manually corrected by manager.", revision, now),
    )


def reset_to_auto(conn, source_type, source_id, revision, payload, transcript_payload):
    conn.execute(
        "UPDATE routes SET is_active=0 WHERE source_type=? AND source_id=? AND is_manual=1",
        (source_type, source_id),
    )
    return route_and_store(conn, source_type, source_id, revision, payload, transcript_payload)


def active_routes_for(conn, source_type, source_id):
    rows = conn.execute(
        """SELECT * FROM routes WHERE source_type=? AND source_id=? AND is_active=1 ORDER BY is_manual DESC, id""",
        (source_type, source_id),
    ).fetchall()
    return [dict(r) for r in rows]
