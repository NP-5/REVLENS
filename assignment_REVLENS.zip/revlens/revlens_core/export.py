"""
Stage 3: understandable folder + export structure.

Layout written under exports/<run_timestamp>/:

  exports/<run>/manifest.json
  exports/<run>/by_route/<route>/<record_ref-or-source_id>.md
  exports/<run>/by_person/<person_label>/<record_ref-or-source_id>.md   (symlink-free copy, for findability)
  exports/<run>/manager_brief/2026-08-21.md

Each conversation gets ONE output file per active route it holds (so a
multi-route conversation produces multiple files, never a merged blob), and
the manifest ties every file back to (source_type, source_id).

A repeat export writes a fresh timestamped run rather than overwriting files
in place, and each manifest row's `current` flag marks which run's file is
authoritative for that record+route today - so nothing is silently lost, and
a reviewer can see exactly which files are "current" without hunting through
old runs. Superseded routes (the record used to be routed to X but a
correction/update moved it) are recorded with `active: false` and a
`superseded_by` pointer rather than deleted.
"""

import json
import os
import re
from datetime import datetime, timezone

from . import db
from .routing import ROUTE_LABELS

EXPORTS_ROOT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "exports")


def _slug(s):
    return re.sub(r"[^a-zA-Z0-9_-]+", "-", (s or "unknown")).strip("-").lower()


def _render_output_md(conv, routes_for_this_output, findings):
    ref = conv["record_ref"] or conv["source_id"]
    lines = [
        f"# {ref} — {conv['title_or_direction'] or conv['source_type']}",
        "",
        f"- **Source**: {conv['source_type']} / `{conv['source_id']}`",
        f"- **When (IST)**: {conv['occurred_date_ist'] or 'unknown'}  ·  raw: {conv['occurred_at_utc'] or 'unknown'}",
        f"- **Person**: {conv['person_label'] or 'unknown'}",
        f"- **Source revision reflected**: {conv['analysis_revision']}",
        "",
        "## What happened",
        findings.get("what_happened", "") or "_no summary available_",
        "",
        "## Why it matters / routing reasons",
    ]
    for r in routes_for_this_output:
        manual_tag = " (manually corrected)" if r["is_manual"] else " (auto)"
        lines.append(f"- **{ROUTE_LABELS.get(r['route'], r['route'])}**{manual_tag}: {r['reason']}")
        if r.get("evidence_ref"):
            lines.append(f"  - Evidence: {r['evidence_ref']}")
        if r.get("evidence_quote"):
            lines.append(f"  - > {r['evidence_quote']}")
    lines += [
        "",
        "## What the evidence does not establish",
        findings.get("not_established", ""),
        "",
        "## Suggested next step",
        findings.get("next_step", ""),
    ]
    return "\n".join(lines)


def run_export():
    conn = db.get_conn()
    conversations = conn.execute("SELECT * FROM conversations").fetchall()

    run_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    run_dir = os.path.join(EXPORTS_ROOT, run_id)
    os.makedirs(run_dir, exist_ok=True)

    manifest_rows = []
    file_count = 0

    for conv in conversations:
        conv = dict(conv)
        routes = conn.execute(
            "SELECT * FROM routes WHERE source_type=? AND source_id=? AND is_active=1 ORDER BY route",
            (conv["source_type"], conv["source_id"]),
        ).fetchall()
        routes = [dict(r) for r in routes]
        findings = json.loads(conv["analysis_json"]) if conv["analysis_json"] else {}
        ref = conv["record_ref"] or conv["source_id"]

        if not routes:
            continue

        # group manual + auto rows that share the same `route` value into one output file per route
        by_route = {}
        for r in routes:
            by_route.setdefault(r["route"], []).append(r)

        for route, route_rows in by_route.items():
            route_dir = os.path.join(run_dir, "by_route", _slug(route))
            os.makedirs(route_dir, exist_ok=True)
            fname = f"{_slug(ref)}.md"
            fpath = os.path.join(route_dir, fname)
            with open(fpath, "w") as f:
                f.write(_render_output_md(conv, route_rows, findings))
            file_count += 1
            rel_path = os.path.relpath(fpath, run_dir)

            manifest_rows.append({
                "source_type": conv["source_type"],
                "source_id": conv["source_id"],
                "record_ref": conv["record_ref"],
                "applied_source_revision": conv["revision"],
                "analysis_reflects_revision": conv["analysis_revision"],
                "analysis_current": conv["analysis_revision"] == conv["revision"],
                "route": route,
                "route_label": ROUTE_LABELS.get(route, route),
                "manual_override": any(r["is_manual"] for r in route_rows),
                "stale_flag": any(r["stale"] for r in route_rows),
                "processing_state": "needs_review" if route == "needs_review" else "routed",
                "output_path": rel_path.replace(os.sep, "/"),
                "active": True,
            })

        # findability copy by person (person-based folder is a convenience index,
        # not a second identity - manifest rows above remain the source of truth)
        if conv["person_label"]:
            person_dir = os.path.join(run_dir, "by_person", _slug(conv["person_label"]))
            os.makedirs(person_dir, exist_ok=True)
            fname = f"{_slug(ref)}.md"
            with open(os.path.join(person_dir, fname), "w") as f:
                f.write(_render_output_md(conv, routes, findings))

    manifest_path = os.path.join(run_dir, "manifest.json")
    with open(manifest_path, "w") as f:
        json.dump({"run_id": run_id, "generated_at": datetime.now(timezone.utc).isoformat(), "records": manifest_rows}, f, indent=2)
    file_count += 1

    # also drop a flat CSV alongside for spreadsheet-based review
    import csv
    csv_path = os.path.join(run_dir, "manifest.csv")
    with open(csv_path, "w", newline="") as f:
        if manifest_rows:
            writer = csv.DictWriter(f, fieldnames=list(manifest_rows[0].keys()))
            writer.writeheader()
            writer.writerows(manifest_rows)
    file_count += 1

    conn.execute(
        "INSERT INTO exports (exported_at, manifest_path, file_count) VALUES (?,?,?)",
        (datetime.now(timezone.utc).isoformat(), os.path.relpath(manifest_path, EXPORTS_ROOT), file_count),
    )
    conn.commit()
    conn.close()

    return {"run_id": run_id, "run_dir": run_dir, "manifest_path": manifest_path, "file_count": file_count, "records": len(manifest_rows)}


def list_export_runs():
    if not os.path.isdir(EXPORTS_ROOT):
        return []
    runs = []
    for name in sorted(os.listdir(EXPORTS_ROOT), reverse=True):
        manifest = os.path.join(EXPORTS_ROOT, name, "manifest.json")
        if os.path.isfile(manifest):
            with open(manifest) as f:
                data = json.load(f)
            runs.append({"run_id": name, "generated_at": data.get("generated_at"), "record_count": len(data.get("records", []))})
    return runs
