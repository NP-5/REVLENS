"""
Manager brief for 21 August 2026 (Asia/Kolkata).

Per the assignment this may be fixed to that date and pre-generated; it does
not need to react to dashboard filters. It is recomputed deterministically
from whatever is currently in the database (so it reflects the update once
applied), but always scoped to occurred_date_ist == '2026-08-21' and to all
44 records rather than any dashboard filter state.
"""

import json
from datetime import datetime, timezone

from . import db
from .routing import ROUTE_LABELS

BRIEF_DATE = "2026-08-21"


def generate_brief():
    conn = db.get_conn()
    convs = [dict(r) for r in conn.execute(
        "SELECT * FROM conversations WHERE occurred_date_ist=?", (BRIEF_DATE,)
    ).fetchall()]

    total = len(convs)
    calls = [c for c in convs if c["source_type"] == "call"]
    meetings = [c for c in convs if c["source_type"] == "meeting"]
    usable = [c for c in convs if c["has_usable_text"]]
    coverage = round(len(usable) / total * 100, 1) if total else 0.0

    by_person = {}
    display_label = {}
    for c in convs:
        key = c["person_email"] or c["person_label"] or "Unknown"
        by_person.setdefault(key, {"total": 0, "usable_text": 0})
        by_person[key]["total"] += 1
        if c["has_usable_text"]:
            by_person[key]["usable_text"] += 1
        if c["person_label"]:
            current = display_label.get(key)
            if current is None or ("@" in current and "@" not in c["person_label"]):
                display_label[key] = c["person_label"]
    for key, v in by_person.items():
        v["display_label"] = display_label.get(key, key)

    route_counts = {}
    highlights = []
    followups = []
    coaching_notes = []

    for c in convs:
        routes = [dict(r) for r in conn.execute(
            "SELECT * FROM routes WHERE source_type=? AND source_id=? AND is_active=1",
            (c["source_type"], c["source_id"]),
        ).fetchall()]
        findings = json.loads(c["analysis_json"]) if c["analysis_json"] else {}
        ref = c["record_ref"] or c["source_id"]

        for r in routes:
            route_counts[r["route"]] = route_counts.get(r["route"], 0) + 1

            if r["route"] == "deal_next_steps":
                highlights.append({
                    "ref": ref, "person": c["person_label"], "reason": r["reason"],
                    "evidence": r.get("evidence_ref"), "quote": r.get("evidence_quote"),
                })
            if r["route"] == "customer_follow_up":
                followups.append({
                    "ref": ref, "person": c["person_label"], "reason": r["reason"],
                    "evidence": r.get("evidence_ref"), "quote": r.get("evidence_quote"),
                    "manual": bool(r["is_manual"]),
                })
            if r["route"] == "sales_coaching":
                coaching_notes.append({
                    "ref": ref, "person": c["person_label"], "reason": r["reason"],
                    "evidence": r.get("evidence_ref"), "quote": r.get("evidence_quote"),
                })

    needs_review_count = sum(1 for c in convs if not c["has_usable_text"])

    brief = {
        "date": BRIEF_DATE,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "totals": {
            "selected_records": total,
            "calls": len(calls),
            "meetings": len(meetings),
            "usable_supplied_text": len(usable),
            "coverage_pct": coverage,
            "needs_review": needs_review_count,
        },
        "by_person": by_person,
        "route_counts": route_counts,
        "deal_highlights": highlights[:6],
        "follow_up_priorities": followups[:6],
        "coaching_notes": coaching_notes[:6],
        "note": (
            "Counts cover the 44 selected source records supplied for this exercise, "
            "not a full or representative day of team activity. Routing is rule-based "
            "evidence, not a verified deal outcome."
        ),
    }
    conn.close()
    return brief
