"""
RevLens storage layer.

Tables
------
source_records   : raw, upserted-by-revision source payloads (identity = source_type+source_id)
conversations     : normalized, one row per source record, safe to recompute at any time
signals           : evidence-backed observations extracted from transcript/turn text
routes            : routing decisions (auto and manual) per conversation, many-to-one
import_history    : one row per import batch applied
"""

import sqlite3
import os

DB_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "instance", "revlens.db")

SCHEMA = """
CREATE TABLE IF NOT EXISTS source_records (
    source_type         TEXT NOT NULL,
    source_id            TEXT NOT NULL,
    record_ref           TEXT,
    revision              INTEGER NOT NULL,
    payload_json          TEXT NOT NULL,
    transcript_payload_json TEXT,
    first_ingested_at     TEXT NOT NULL,
    last_updated_at        TEXT NOT NULL,
    last_batch_id          TEXT,
    PRIMARY KEY (source_type, source_id)
);

CREATE TABLE IF NOT EXISTS conversations (
    source_type       TEXT NOT NULL,
    source_id          TEXT NOT NULL,
    record_ref         TEXT,
    revision            INTEGER NOT NULL,
    occurred_at_utc     TEXT,
    occurred_date_ist   TEXT,
    person_email        TEXT,
    person_label         TEXT,
    person_role_guess    TEXT,
    title_or_direction   TEXT,
    duration_seconds     INTEGER,
    has_usable_text       INTEGER NOT NULL DEFAULT 0,
    text_source           TEXT,
    connected_status       TEXT,
    review_reason          TEXT,
    analysis_json           TEXT,
    analysis_revision        INTEGER,
    updated_at             TEXT NOT NULL,
    PRIMARY KEY (source_type, source_id)
);

CREATE TABLE IF NOT EXISTS signals (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    source_type    TEXT NOT NULL,
    source_id      TEXT NOT NULL,
    kind           TEXT NOT NULL,
    label          TEXT NOT NULL,
    evidence_ref   TEXT,
    evidence_quote TEXT,
    rule_name      TEXT,
    revision       INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS routes (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    source_type     TEXT NOT NULL,
    source_id       TEXT NOT NULL,
    route           TEXT NOT NULL,
    reason          TEXT,
    is_manual       INTEGER NOT NULL DEFAULT 0,
    is_active       INTEGER NOT NULL DEFAULT 1,
    source_revision INTEGER NOT NULL,
    stale           INTEGER NOT NULL DEFAULT 0,
    created_at      TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS import_history (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    batch_id        TEXT,
    revision        INTEGER,
    imported_at     TEXT NOT NULL,
    records_seen    INTEGER,
    records_new     INTEGER,
    records_updated INTEGER,
    records_ignored_stale INTEGER
);

CREATE TABLE IF NOT EXISTS exports (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    exported_at  TEXT NOT NULL,
    manifest_path TEXT NOT NULL,
    file_count    INTEGER
);
"""


def get_conn():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db():
    conn = get_conn()
    conn.executescript(SCHEMA)
    conn.commit()
    conn.close()


def reset_db():
    """Full clean start: drop and recreate every table."""
    conn = get_conn()
    conn.executescript("""
        DROP TABLE IF EXISTS source_records;
        DROP TABLE IF EXISTS conversations;
        DROP TABLE IF EXISTS signals;
        DROP TABLE IF EXISTS routes;
        DROP TABLE IF EXISTS import_history;
        DROP TABLE IF EXISTS exports;
    """)
    conn.executescript(SCHEMA)
    conn.commit()
    conn.close()
