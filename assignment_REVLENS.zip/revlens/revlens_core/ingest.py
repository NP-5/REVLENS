"""
Stage 1-4 of the pipeline: INGEST -> NORMALIZE -> VALIDATE -> DEDUPLICATE/UPSERT.

Supports three input shapes, auto-detected from file content (not just extension),
matching the landing page's "CSV / JSON / Transcript" intake claim:

  * JSON envelope  - the assignment's OXO-shaped delivery (batch_id/revision/records[])
  * CSV            - a flat one-row-per-conversation sheet with the same field names
                      as the JSON envelope's flattened columns (source_type, source_id,
                      transcript / turns_json, etc). Included so the ingest stage is not
                      hard-wired to only the sample files.
  * Plain transcript - a single .txt file containing one call/meeting's raw text, for
                      manually dropping in a one-off transcript. Minimal metadata is
                      inferred (source_id = filename) and it is flagged for review since
                      the required metadata fields are not present.

Every path converges on the same normalized `record` dict before validation/dedupe,
so storage and routing never need to know which format a record arrived in.
"""

import csv
import io
import json
import re
import uuid
from datetime import datetime, timezone
from zoneinfo import ZoneInfo

from . import db
from . import routing

IST = ZoneInfo("Asia/Kolkata")

REQUIRED_CALL_FIELDS = ["id", "started_at", "direction"]
REQUIRED_MEETING_FIELDS = ["id", "starts_at", "title"]


# ---------------------------------------------------------------------------
# 1. INGEST: format detection
# ---------------------------------------------------------------------------

def detect_format(raw_bytes: bytes, filename: str = "") -> str:
    text = raw_bytes.decode("utf-8", errors="replace").strip()
    if filename.lower().endswith(".json") or text.startswith("{") or text.startswith("["):
        return "json"
    if filename.lower().endswith(".csv") or ("," in text.splitlines()[0] if text.splitlines() else False):
        # cheap heuristic: first line looks like a comma header row
        first_line = text.splitlines()[0] if text.splitlines() else ""
        if "source_type" in first_line or "source_id" in first_line:
            return "csv"
    return "transcript"


def load_records_from_bytes(raw_bytes: bytes, filename: str = ""):
    """Returns (batch_id, revision, exported_at, list_of_raw_records, detected_format)."""
    fmt = detect_format(raw_bytes, filename)
    text = raw_bytes.decode("utf-8", errors="replace")

    if fmt == "json":
        envelope = json.loads(text)
        return (
            envelope.get("batch_id", filename),
            int(envelope.get("revision", 1)),
            envelope.get("exported_at"),
            envelope.get("records", []),
            fmt,
        )

    if fmt == "csv":
        reader = csv.DictReader(io.StringIO(text))
        records = []
        for row in reader:
            payload = {k: v for k, v in row.items() if k not in ("source_type", "source_id", "record_ref", "revision")}
            if row.get("source_type") == "meeting" and row.get("turns_json"):
                transcript_payload = {"meeting_id": row.get("source_id"), "turns": json.loads(row["turns_json"])}
            else:
                transcript_payload = None
            records.append({
                "record_ref": row.get("record_ref"),
                "source_type": row.get("source_type", "call"),
                "source_id": row.get("source_id") or str(uuid.uuid4()),
                "payload": payload,
                "transcript_payload": transcript_payload,
            })
        return (filename or "csv-upload", 1, None, records, fmt)

    # plain transcript: one file = one unmetadata'd call, flagged for review
    source_id = f"txt-{re.sub(r'[^a-zA-Z0-9]+', '-', filename or str(uuid.uuid4()))}"
    record = {
        "record_ref": None,
        "source_type": "call",
        "source_id": source_id,
        "payload": {
            "id": source_id,
            "started_at": None,
            "direction": None,
            "transcript": text.strip(),
            "rep_email": None,
            "rep_name": None,
        },
        "transcript_payload": None,
        "_needs_review_reason": "Uploaded as a raw transcript file with no source metadata; date/rep/direction are unknown.",
    }
    return (filename or "manual-upload", 1, None, [record], fmt)


# ---------------------------------------------------------------------------
# 2. NORMALIZE: common schema
# ---------------------------------------------------------------------------

def _to_ist_date(iso_ts):
    if not iso_ts:
        return None
    try:
        dt = datetime.fromisoformat(iso_ts.replace("Z", "+00:00"))
        return dt.astimezone(IST).date().isoformat()
    except Exception:
        return None


def normalize_record(raw):
    """Builds the common schema used by validate/dedupe/store, regardless of source format."""
    source_type = raw.get("source_type")
    payload = raw.get("payload") or {}
    transcript_payload = raw.get("transcript_payload")

    if source_type == "call":
        occurred_at = payload.get("started_at")
        text_source = "call_transcript" if (payload.get("transcript") or "").strip() else None
        has_text = bool((payload.get("transcript") or "").strip())
        person_email = payload.get("rep_email")
        person_label = payload.get("rep_name") or payload.get("rep_email")
        title_or_direction = payload.get("direction")
        duration = payload.get("duration_seconds")
        connected = payload.get("is_connected")
        connected_status = "unknown" if connected is None else ("connected" if connected else "not_connected")
    else:  # meeting
        occurred_at = payload.get("starts_at")
        turns = (transcript_payload or {}).get("turns") or []
        has_text = any((t.get("text") or "").strip() for t in turns)
        text_source = "meeting_turns" if has_text else None
        person_email = payload.get("organizer_email")
        person_label = payload.get("organizer_email")
        title_or_direction = payload.get("title")
        duration = payload.get("duration_seconds")
        connected_status = None

    review_reason = raw.get("_needs_review_reason")
    if not has_text and not review_reason:
        if source_type == "call":
            review_reason = "No usable transcript supplied for this call (background/no-text record)."
        else:
            unavailable = (transcript_payload or {}).get("unavailable_reason") if transcript_payload else None
            review_reason = unavailable or "No usable meeting turns supplied for this record."

    return {
        "source_type": source_type,
        "source_id": raw.get("source_id"),
        "record_ref": raw.get("record_ref"),
        "payload": payload,
        "transcript_payload": transcript_payload,
        "occurred_at_utc": occurred_at,
        "occurred_date_ist": _to_ist_date(occurred_at),
        "person_email": person_email,
        "person_label": person_label,
        "title_or_direction": title_or_direction,
        "duration_seconds": duration,
        "has_usable_text": has_text,
        "text_source": text_source,
        "connected_status": connected_status,
        "review_reason": review_reason,
    }


# ---------------------------------------------------------------------------
# 3. VALIDATE
# ---------------------------------------------------------------------------

def validate_record(norm):
    """Returns list of validation problems (empty = valid enough to store)."""
    problems = []
    if not norm["source_type"] in ("call", "meeting"):
        problems.append(f"Unknown source_type: {norm['source_type']!r}")
    if not norm["source_id"]:
        problems.append("Missing source_id (record identity requires source_type+source_id).")

    required = REQUIRED_CALL_FIELDS if norm["source_type"] == "call" else REQUIRED_MEETING_FIELDS
    for field in required:
        if norm["payload"].get(field) in (None, ""):
            problems.append(f"Missing required field on {norm['source_type']}: {field}")
    return problems


# ---------------------------------------------------------------------------
# 4. DEDUPLICATE / UPSERT (identity = (source_type, source_id), by revision)
# ---------------------------------------------------------------------------

def apply_batch(raw_bytes: bytes, filename: str = ""):
    """
    Runs the full ingest -> normalize -> validate -> dedupe/store pipeline for one
    uploaded file and records import history. Returns a summary dict.
    """
    batch_id, revision, exported_at, raw_records, fmt = load_records_from_bytes(raw_bytes, filename)

    conn = db.get_conn()
    seen = 0
    new_count = 0
    updated_count = 0
    ignored_stale = 0
    rejected = []

    for raw in raw_records:
        seen += 1
        norm = normalize_record(raw)
        problems = validate_record(norm)
        if problems:
            rejected.append({"source_type": norm.get("source_type"), "source_id": norm.get("source_id"), "problems": problems})
            continue

        rec_revision = revision
        existing = conn.execute(
            "SELECT revision FROM source_records WHERE source_type=? AND source_id=?",
            (norm["source_type"], norm["source_id"]),
        ).fetchone()

        now = datetime.now(timezone.utc).isoformat()

        if existing is None:
            conn.execute(
                """INSERT INTO source_records
                   (source_type, source_id, record_ref, revision, payload_json, transcript_payload_json,
                    first_ingested_at, last_updated_at, last_batch_id)
                   VALUES (?,?,?,?,?,?,?,?,?)""",
                (norm["source_type"], norm["source_id"], norm["record_ref"], rec_revision,
                 json.dumps(norm["payload"]), json.dumps(norm["transcript_payload"]), now, now, batch_id),
            )
            new_count += 1
            _upsert_conversation(conn, norm, rec_revision, now)
            routing.route_and_store(conn, norm["source_type"], norm["source_id"], rec_revision,
                                     norm["payload"], norm["transcript_payload"])
        elif rec_revision > existing["revision"]:
            conn.execute(
                """UPDATE source_records SET record_ref=?, revision=?, payload_json=?, transcript_payload_json=?,
                   last_updated_at=?, last_batch_id=? WHERE source_type=? AND source_id=?""",
                (norm["record_ref"], rec_revision, json.dumps(norm["payload"]), json.dumps(norm["transcript_payload"]),
                 now, batch_id, norm["source_type"], norm["source_id"]),
            )
            updated_count += 1
            _upsert_conversation(conn, norm, rec_revision, now)
            # Source text changed: recompute the AUTO analysis/route at the new revision.
            # Manual overrides (routing.route_and_store only touches is_manual=0 rows)
            # remain untouched and stay in effect, per contract rule #4.
            routing.route_and_store(conn, norm["source_type"], norm["source_id"], rec_revision,
                                     norm["payload"], norm["transcript_payload"])
            _flag_manual_route_possibly_outdated(conn, norm, rec_revision)
        else:
            ignored_stale += 1

    conn.execute(
        """INSERT INTO import_history (batch_id, revision, imported_at, records_seen, records_new, records_updated, records_ignored_stale)
           VALUES (?,?,?,?,?,?,?)""",
        (batch_id, revision, datetime.now(timezone.utc).isoformat(), seen, new_count, updated_count, ignored_stale),
    )
    conn.commit()
    conn.close()

    return {
        "batch_id": batch_id,
        "revision": revision,
        "format": fmt,
        "records_seen": seen,
        "records_new": new_count,
        "records_updated": updated_count,
        "records_ignored_stale": ignored_stale,
        "rejected": rejected,
    }


def _upsert_conversation(conn, norm, revision, now):
    conn.execute(
        """INSERT INTO conversations
           (source_type, source_id, record_ref, revision, occurred_at_utc, occurred_date_ist,
            person_email, person_label, person_role_guess, title_or_direction, duration_seconds,
            has_usable_text, text_source, connected_status, review_reason, updated_at)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
           ON CONFLICT(source_type, source_id) DO UPDATE SET
             record_ref=excluded.record_ref, revision=excluded.revision,
             occurred_at_utc=excluded.occurred_at_utc, occurred_date_ist=excluded.occurred_date_ist,
             person_email=excluded.person_email, person_label=excluded.person_label,
             title_or_direction=excluded.title_or_direction, duration_seconds=excluded.duration_seconds,
             has_usable_text=excluded.has_usable_text, text_source=excluded.text_source,
             connected_status=excluded.connected_status, review_reason=excluded.review_reason,
             updated_at=excluded.updated_at""",
        (norm["source_type"], norm["source_id"], norm["record_ref"], revision,
         norm["occurred_at_utc"], norm["occurred_date_ist"], norm["person_email"], norm["person_label"],
         None, norm["title_or_direction"], norm["duration_seconds"], int(norm["has_usable_text"]),
         norm["text_source"], norm["connected_status"], norm["review_reason"], now),
    )


def _flag_manual_route_possibly_outdated(conn, norm, new_revision):
    """
    A manual route survives a source update untouched (contract rule #4), but if new
    text arrived after the manual decision was made, flag it `stale` purely as a
    display hint ("set before this update, source has changed") - the route itself
    is not changed or removed, and only an explicit reset clears it.
    """
    conn.execute(
        """UPDATE routes SET stale=1
           WHERE source_type=? AND source_id=? AND is_active=1 AND is_manual=1 AND source_revision < ?""",
        (norm["source_type"], norm["source_id"], new_revision),
    )
