const ROUTE_LABELS = {
  sales_coaching: "Sales coaching",
  deal_next_steps: "Deal next steps",
  customer_follow_up: "Customer follow-up",
  internal_vendor_note: "Internal / vendor note",
  needs_review: "Needs review",
};

function toast(msg) {
  const root = document.getElementById("toast-root");
  if (!root) { console.log(msg); return; }
  const el = document.createElement("div");
  el.className = "toast";
  el.textContent = msg;
  root.appendChild(el);
  setTimeout(() => el.remove(), 4200);
}

async function api(path, opts) {
  const res = await fetch(path, opts);
  if (!res.ok) {
    const body = await res.text();
    throw new Error(`${res.status}: ${body}`);
  }
  return res.json();
}

function routeBadges(routes) {
  if (!routes || !routes.length) return '<span class="pill-muted">—</span>';
  return routes.map(r => {
    const cls = `badge badge-${r.route}${r.is_manual ? " manual" : ""}${r.stale ? " stale" : ""}`;
    return `<span class="${cls}" title="${escapeHtml(r.reason || "")}">${ROUTE_LABELS[r.route] || r.route}</span>`;
  }).join(" ");
}

// Calls report rep_email (a caller account identifier, grouped as the person on
// the call). Meetings only report organizer_email, which the data dictionary is
// explicit is "not proof of attendance or selling role" — no organiser-to-speaker
// mapping is supplied. Surface that distinction wherever a person label appears,
// rather than only in the README.
function personRoleTag(sourceType) {
  if (sourceType === "call") {
    return `<span class="pill-muted role-tag" title="From rep_email — a caller account identifier used for grouping.">rep</span>`;
  }
  if (sourceType === "meeting") {
    return `<span class="pill-muted role-tag" title="From organizer_email — the calendar organiser, not proof of attendance or a confirmed selling role. No organiser-to-transcript-speaker mapping is supplied.">organiser⚠</span>`;
  }
  return "";
}

function escapeHtml(s) {
  return (s || "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

function fmtDate(iso) {
  if (!iso) return "—";
  return iso.replace("T", " ").replace("Z", " UTC");
}

function donutSVG(segments, size = 112, stroke = 16) {
  const total = segments.reduce((s, x) => s + x.value, 0);
  const r = (size - stroke) / 2, c = size / 2, circ = 2 * Math.PI * r;
  let offset = 0;
  const circles = total === 0
    ? `<circle cx="${c}" cy="${c}" r="${r}" fill="none" stroke="var(--line)" stroke-width="${stroke}"></circle>`
    : segments.filter(s => s.value > 0).map(seg => {
        const dash = (seg.value / total) * circ;
        const el = `<circle cx="${c}" cy="${c}" r="${r}" fill="none" stroke="${seg.color}" stroke-width="${stroke}" stroke-dasharray="${dash.toFixed(2)} ${(circ - dash).toFixed(2)}" stroke-dashoffset="${(-offset).toFixed(2)}" transform="rotate(-90 ${c} ${c})"><title>${escapeHtml(seg.label)}: ${seg.value}</title></circle>`;
        offset += dash;
        return el;
      }).join("");
  return `<svg viewBox="0 0 ${size} ${size}" width="${size}" height="${size}" style="flex:none;">${circles}<text x="${c}" y="${c}" text-anchor="middle" dominant-baseline="central" class="donut-total">${total}</text></svg>`;
}

function chartLegend(segments) {
  return `<div class="chart-legend">${segments.map(s => `<span><i class="swatch" style="background:${s.color}"></i>${escapeHtml(s.label)}<b>${s.value}</b></span>`).join("")}</div>`;
}

function barChartHTML(items) {
  const max = Math.max(...items.map(i => i.value), 1);
  return `<div class="bar-chart">${items.map(i => `
    <div class="bar-row">
      <div class="bar-row-label">${escapeHtml(i.label)}</div>
      <div class="bar-row-track"><div class="bar-row-fill" style="width:${(i.value / max * 100).toFixed(1)}%; background:${i.color};"></div></div>
      <div class="bar-row-val">${i.value}</div>
    </div>`).join("")}</div>`;
}

const ROUTE_COLORS = {
  sales_coaching: "var(--route-coaching)",
  deal_next_steps: "var(--route-deal)",
  customer_follow_up: "var(--route-followup)",
  internal_vendor_note: "var(--route-vendor)",
  needs_review: "var(--route-review)",
};

function renderCharts(rows) {
  const srcEl = document.getElementById("chart-source-type");
  const covEl = document.getElementById("chart-coverage");
  const routeEl = document.getElementById("chart-routes");
  if (!srcEl) return; // not on this page

  if (!rows.length) {
    const empty = `<p class="pill-muted">No data in the current view.</p>`;
    srcEl.innerHTML = empty; covEl.innerHTML = empty; routeEl.innerHTML = empty;
    return;
  }

  const calls = rows.filter(r => r.source_type === "call").length;
  const meetings = rows.filter(r => r.source_type === "meeting").length;
  const srcSegs = [
    { value: calls, color: "var(--accent)", label: "Calls" },
    { value: meetings, color: "var(--route-followup)", label: "Meetings" },
  ];
  srcEl.innerHTML = donutSVG(srcSegs) + chartLegend(srcSegs);

  const usable = rows.filter(r => r.has_usable_text).length;
  const missing = rows.length - usable;
  const covSegs = [
    { value: usable, color: "var(--route-followup)", label: "Usable text" },
    { value: missing, color: "var(--route-review)", label: "No text" },
  ];
  covEl.innerHTML = donutSVG(covSegs) + chartLegend(covSegs);

  const routeCounts = {};
  rows.forEach(r => (r.routes || []).forEach(x => { routeCounts[x.route] = (routeCounts[x.route] || 0) + 1; }));
  const routeItems = Object.keys(ROUTE_LABELS).map(r => ({
    label: ROUTE_LABELS[r], value: routeCounts[r] || 0, color: ROUTE_COLORS[r],
  }));
  routeEl.innerHTML = barChartHTML(routeItems);
}

// ---------------------------------------------------------------------
// Dashboard page
// ---------------------------------------------------------------------

async function initDashboard() {
  document.getElementById("btn-import-initial").onclick = () => runImport("initial");
  document.getElementById("btn-import-update").onclick = () => runImport("update");
  document.getElementById("btn-reset").onclick = async () => {
    if (!confirm("Reset clears all imported data, routes and manual corrections. Continue?")) return;
    await api("/api/reset", { method: "POST" });
    toast("Reset complete. Import the initial batch to begin.");
    loadMetrics(); loadConversations();
  };

  let activeFilters = { person: null, source_type: null, route: null, review_only: null };

  async function runImport(which) {
    try {
      const r = await api(`/api/import/sample/${which}`, { method: "POST" });
      toast(`Imported ${which}: ${r.records_new} new, ${r.records_updated} updated, ${r.records_ignored_stale} ignored (stale revision).`);
      await loadMetrics();
      await loadConversations(activeFilters);
      await loadImportHistory();
    } catch (e) { toast("Import failed: " + e.message); }
  }

  async function loadImportHistory() {
    const state = await api("/api/state");
    const box = document.getElementById("import-history");
    const body = document.getElementById("import-history-body");
    if (!state.import_history.length) { box.style.display = "none"; return; }
    box.style.display = "block";
    body.innerHTML = state.import_history.map(h =>
      `${fmtDate(h.imported_at)} — batch <b>${h.batch_id}</b> rev ${h.revision}: seen ${h.records_seen}, new ${h.records_new}, updated ${h.records_updated}, ignored(stale) ${h.records_ignored_stale}`
    ).join("<br>");
  }

  async function loadMetrics() {
    const m = await api("/api/metrics");
    const grid = document.getElementById("metrics");
    const conn = m.connection_rate;
    grid.innerHTML = `
      <div class="metric-card"><div class="num">${m.selected_records_total}</div><div class="label">Selected source records</div><div class="def">Distinct (source_type, source_id) after revisions applied.</div></div>
      <div class="metric-card"><div class="num">${m.usable_supplied_text} / ${m.selected_records_total}</div><div class="label">Usable-text coverage — ${m.coverage_pct}%</div><div class="def">${m.coverage_definition}</div></div>
      <div class="metric-card"><div class="num">${conn.pct !== null ? conn.pct + "%" : "—"}</div><div class="label">Source-reported connection rate</div><div class="def">${conn.connected}/${conn.known_denominator} known; ${conn.unknown_excluded} unknown excluded. Stored classification, not a transcript check.</div></div>
      <div class="metric-card"><div class="num">${m.labelled_route_assignments}</div><div class="label">Labelled route assignments</div><div class="def">Can exceed ${m.unique_records} unique records — a conversation may need more than one route.</div></div>
    `;
    const filters = document.getElementById("filters");
    const people = Object.keys(m.by_person).sort();
    const routeChips = Object.keys(ROUTE_LABELS).map(r => {
      const count = (m.routes_summary[r] || {}).count || 0;
      return `<button class="tag" data-kind="route" data-val="${r}">${ROUTE_LABELS[r]} (${count})</button>`;
    }).join("");
    filters.innerHTML = `
      <button class="tag" data-kind="source_type" data-val="call">Calls</button>
      <button class="tag" data-kind="source_type" data-val="meeting">Meetings</button>
      <button class="tag" data-kind="review_only" data-val="1">Needs review only</button>
      ${routeChips}
      <select id="person-filter"><option value="">All people</option>${people.map(p => `<option value="${escapeHtml(p)}">${escapeHtml(m.by_person[p].display_label || p)}</option>`).join("")}</select>
    `;
    filters.querySelectorAll(".tag").forEach(btn => {
      btn.onclick = () => {
        const kind = btn.dataset.kind, val = btn.dataset.val;
        if (activeFilters[kind] === val) { activeFilters[kind] = null; btn.classList.remove("active"); }
        else {
          if (kind === "source_type") filters.querySelectorAll('[data-kind=source_type]').forEach(b => b.classList.remove("active"));
          if (kind === "route") filters.route = activeFilters.route === val ? null : val;
          activeFilters[kind] = val; btn.classList.add("active");
        }
        loadConversations(activeFilters);
      };
    });
    document.getElementById("person-filter").onchange = (e) => {
      activeFilters.person = e.target.value || null;
      loadConversations(activeFilters);
    };
  }

  async function loadConversations(filters = {}) {
    const params = new URLSearchParams();
    Object.entries(filters).forEach(([k, v]) => { if (v) params.set(k, v); });
    const rows = await api(`/api/conversations?${params.toString()}`);
    renderCharts(rows);
    const tbody = document.getElementById("conv-tbody");
    if (!rows.length) { tbody.innerHTML = `<tr><td colspan="6" class="loading">No conversations match — import the initial batch to begin.</td></tr>`; return; }
    tbody.innerHTML = rows.map(c => `
      <tr onclick="location.href='/app/conversation/${c.source_type}/${c.source_id}'">
        <td class="ref">${c.record_ref || c.source_id.slice(0,8)}</td>
        <td>${c.source_type}</td>
        <td>${c.occurred_at_utc ? new Date(c.occurred_at_utc).toLocaleString("en-IN", { timeZone: "Asia/Kolkata", hour12: false }) : "—"}</td>
        <td>${escapeHtml(c.person_label || "—")} ${personRoleTag(c.source_type)}</td>
        <td>${c.has_usable_text ? "✓ text" : `<span class="pill-muted">${escapeHtml(c.review_reason || "no text")}</span>`}</td>
        <td>${routeBadges(c.routes)}</td>
      </tr>
    `).join("");
  }

  loadMetrics();
  loadConversations();
  loadImportHistory();
}

// ---------------------------------------------------------------------
// Conversation detail page
// ---------------------------------------------------------------------

async function initConversation() {
  const body = document.body;
  const sourceType = body.dataset.sourceType, sourceId = body.dataset.sourceId;
  const root = document.getElementById("detail-root");

  async function render() {
    const c = await api(`/api/conversation/${sourceType}/${sourceId}`);
    const findings = c.analysis || {};
    const p = c.payload;

    let transcriptHtml = "";
    if (c.source_type === "call") {
      transcriptHtml = `<div class="transcript mono" style="white-space:pre-wrap;">${escapeHtml(p.transcript || "(no transcript)")}</div>`;
    } else {
      const turns = (c.transcript_payload && c.transcript_payload.turns) || [];
      transcriptHtml = turns.length
        ? turns.map((t, i) => `<div class="turn"><div class="who">#${i+1} · ${escapeHtml(t.speaker)} · ${t.timecode || ""}</div>${escapeHtml(t.text)}</div>`).join("")
        : `<div class="pill-muted">${escapeHtml((c.transcript_payload && c.transcript_payload.unavailable_reason) || "No usable turns supplied.")}</div>`;
    }

    const routeOptions = Object.keys(ROUTE_LABELS).map(r => `<option value="${r}">${ROUTE_LABELS[r]}</option>`).join("");

    root.innerHTML = `
      <div class="page-head">
        <div>
          <h1>${escapeHtml(c.record_ref || c.source_id)} <span class="pill-muted mono">· ${c.source_type} · rev ${c.revision}</span></h1>
          <div class="desc">${escapeHtml(c.title_or_direction || "")} — ${escapeHtml(c.person_label || "unknown person")} ${personRoleTag(c.source_type)} — ${c.occurred_at_utc ? new Date(c.occurred_at_utc).toLocaleString("en-IN", { timeZone: "Asia/Kolkata", hour12: false }) + " IST" : "date unknown"}</div>
          ${c.source_type === "meeting" ? `<div class="pill-muted" style="margin-top:4px;">This meeting's person is the calendar organiser (<span class="mono">organizer_email</span>), not a confirmed salesperson or attendee — the data dictionary supplies no organiser-to-speaker mapping.</div>` : ""}
        </div>
        <a href="/app" class="btn">← back to overview</a>
      </div>

      <div class="panel">
        <h3>Routing</h3>
        <div style="margin-bottom:10px;">${routeBadges(c.routes)}</div>
        ${(c.routes || []).map(r => `
          <div style="margin-bottom:8px; font-size:13px;">
            <b>${ROUTE_LABELS[r.route] || r.route}</b>${r.is_manual ? " — manually set" : " — auto"}${r.stale ? " <span class='pill-muted'>(source updated since this was set — review)</span>" : ""}<br>
            <span class="pill-muted">${escapeHtml(r.reason || "")}</span>
            ${r.evidence_ref ? `<div class="evidence-quote">${escapeHtml(r.evidence_ref)}${r.evidence_quote ? ": " + escapeHtml(r.evidence_quote) : ""}</div>` : ""}
          </div>
        `).join("")}
        <div style="display:flex; gap:8px; margin-top:14px; align-items:center;">
          <select id="route-select">${routeOptions}</select>
          <button id="btn-set-route" class="btn btn-primary">Correct route</button>
          <button id="btn-reset-route" class="btn">Reset to auto</button>
        </div>
      </div>

      <div class="panel">
        <h3>Analysis</h3>
        <p><b>${escapeHtml(findings.headline || "")}</b></p>
        <p>${escapeHtml(findings.what_happened || "")}</p>
        <p class="pill-muted"><b>Not established:</b> ${escapeHtml(findings.not_established || "")}</p>
        <p><b>Suggested next step:</b> ${escapeHtml(findings.next_step || "")}</p>
        <p class="pill-muted mono" style="font-size:11px;">Analysis reflects source revision ${c.analysis_revision}${c.analysis_revision !== c.revision ? " — source is now at rev " + c.revision + ", re-import/update to refresh" : " (current)"}.</p>
      </div>

      <div class="panel">
        <h3>Source metadata</h3>
        <dl class="kv">
          <dt>source_id</dt><dd class="mono">${escapeHtml(c.source_id)}</dd>
          <dt>connected</dt><dd>${escapeHtml(String(c.connected_status || "n/a"))}</dd>
          <dt>duration_seconds</dt><dd>${c.duration_seconds ?? "—"}</dd>
        </dl>
      </div>

      <div class="panel">
        <h3>Transcript</h3>
        ${transcriptHtml}
      </div>
    `;

    document.getElementById("btn-set-route").onclick = async () => {
      const route = document.getElementById("route-select").value;
      const reason = prompt("Optional note for this correction:", "") || "Manually corrected by manager.";
      await api(`/api/route/${sourceType}/${sourceId}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ route, reason }) });
      toast("Route corrected — this will persist through future imports.");
      render();
    };
    document.getElementById("btn-reset-route").onclick = async () => {
      await api(`/api/route/${sourceType}/${sourceId}/reset`, { method: "POST" });
      toast("Reset to automatic routing.");
      render();
    };
  }

  render();
}

// ---------------------------------------------------------------------
// Brief page
// ---------------------------------------------------------------------

async function initBrief() {
  const root = document.getElementById("brief-root");
  const b = await api("/api/brief");
  const t = b.totals;

  function evList(items, emptyMsg) {
    if (!items.length) return `<p class="pill-muted">${emptyMsg}</p>`;
    return items.map(i => `
      <div style="margin-bottom:12px; padding-bottom:12px; border-bottom:1px solid var(--line-soft);">
        <b>${escapeHtml(i.ref)}</b> <span class="pill-muted">· ${escapeHtml(i.person || "unknown")}</span>
        ${i.manual ? '<span class="badge manual">manual</span>' : ""}
        <div style="font-size:13px; margin-top:4px;">${escapeHtml(i.reason)}</div>
        ${i.quote ? `<div class="evidence-quote">${escapeHtml(i.evidence || "")}: ${escapeHtml(i.quote)}</div>` : ""}
      </div>
    `).join("");
  }

  root.innerHTML = `
    <div class="page-head">
      <div>
        <h1>Manager brief — 21 August 2026 (Asia/Kolkata)</h1>
        <div class="desc">Fixed to this date; recomputed from the current database state so it reflects the update once applied, but not affected by dashboard filters. Generated ${fmtDate(b.generated_at)}.</div>
      </div>
    </div>

    <div class="metrics-grid">
      <div class="metric-card"><div class="num">${t.selected_records}</div><div class="label">Selected records</div></div>
      <div class="metric-card"><div class="num">${t.calls} / ${t.meetings}</div><div class="label">Calls / meetings</div></div>
      <div class="metric-card"><div class="num">${t.usable_supplied_text}</div><div class="label">Usable-text (${t.coverage_pct}%)</div></div>
      <div class="metric-card"><div class="num">${t.needs_review}</div><div class="label">Needs review — no usable text</div></div>
    </div>

    <div class="panel">
      <h3>Deal next steps worth a look</h3>
      ${evList(b.deal_highlights, "No conversations were routed to deal next steps in this window.")}
    </div>
    <div class="panel">
      <h3>Customer follow-up priorities</h3>
      ${evList(b.follow_up_priorities, "No conversations were routed to customer follow-up in this window.")}
    </div>
    <div class="panel">
      <h3>Coaching notes</h3>
      ${evList(b.coaching_notes, "No conversations were routed to sales coaching in this window.")}
    </div>
    <p class="pill-muted" style="font-size:12px;">${escapeHtml(b.note)}</p>
  `;
}

// ---------------------------------------------------------------------
// Exports page
// ---------------------------------------------------------------------

async function initExports() {
  const root = document.getElementById("exports-root");
  document.getElementById("btn-run-export").onclick = async () => {
    const r = await api("/api/export", { method: "POST" });
    toast(`Export run ${r.run_id}: ${r.file_count} files for ${r.records} route assignments.`);
    load();
  };
  async function load() {
    const runs = await api("/api/exports");
    if (!runs.length) { root.innerHTML = `<p class="pill-muted">No export runs yet — click "Run export".</p>`; return; }
    root.innerHTML = `<table class="grid-table"><thead><tr><th>Run</th><th>Generated</th><th>Route assignments</th><th>Manifest</th></tr></thead><tbody>
      ${runs.map(r => `<tr>
        <td class="ref">${r.run_id}</td>
        <td>${fmtDate(r.generated_at)}</td>
        <td>${r.record_count}</td>
        <td><a href="/exports/${r.run_id}/manifest.json" target="_blank">JSON</a> · <a href="/exports/${r.run_id}/manifest.csv" target="_blank">CSV</a></td>
      </tr>`).join("")}
    </tbody></table>`;
  }
  load();
}

// ---------------------------------------------------------------------
// Landing page
// ---------------------------------------------------------------------

async function initLanding() {
  const strip = document.getElementById("landing-strip");

  let rows;
  try {
    rows = await api("/api/conversations");
  } catch (e) {
    strip.innerHTML = `<div><div class="num">—</div><div class="lbl">Couldn't reach the workspace API.</div></div>`;
    return;
  }

  if (!rows.length) {
    strip.innerHTML = `<div><div class="num">0</div><div class="lbl">source records tracked — <a href="/app">open the workspace</a> and import a batch to begin</div></div>`;
    return;
  }

  const calls = rows.filter(r => r.source_type === "call").length;
  const meetings = rows.filter(r => r.source_type === "meeting").length;
  const usable = rows.filter(r => r.has_usable_text).length;
  const routeCount = new Set(rows.flatMap(r => r.routes.map(x => x.route))).size;

  strip.innerHTML = `
    <div><div class="num">${rows.length}</div><div class="lbl">source records tracked (${calls} calls, ${meetings} meetings)</div></div>
    <div><div class="num">${usable}</div><div class="lbl">carry usable transcript text right now</div></div>
    <div><div class="num">${routeCount}</div><div class="lbl">routing destinations, evidence-linked to source text</div></div>
  `;
}

document.addEventListener("DOMContentLoaded", () => {
  const page = document.body.dataset.page;
  if (page === "dashboard") initDashboard();
  else if (page === "conversation") initConversation();
  else if (page === "brief") initBrief();
  else if (page === "exports") initExports();
  else if (page === "landing") initLanding();
});
